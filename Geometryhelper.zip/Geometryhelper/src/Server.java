import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Server {
    private static final int PORT = 80;
    private static final int TIMEOUT = 120000;

    public static void main(String[] args) {
        try {
            ServerSocket serverSocket = new ServerSocket(PORT);
            serverSocket.setSoTimeout(TIMEOUT);
            System.out.println("Server avviato sulla porta " + PORT);

            ExecutorService executor = Executors.newCachedThreadPool();

            while (true) {
                try {
                    Socket clientSocket = serverSocket.accept();
                    System.out.println("Nuova connessione accettata.");

                    executor.execute(new ClientHandler(clientSocket));
                } catch (IOException e) {
                    System.err.println("Errore durante la connessione del client: " + e.getMessage());
                }
            }
        } catch (IOException e) {
            System.err.println("Impossibile avviare il server sulla porta " + PORT + ": " + e.getMessage());
        }
    }

    private static class ClientHandler implements Runnable {
        private final Socket clientSocket;

        public ClientHandler(Socket clientSocket) {
            this.clientSocket = clientSocket;
        }
        @Override
        public void run() {
            try {
                BufferedReader input = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                PrintWriter output = new PrintWriter(clientSocket.getOutputStream(), true);

                String request = input.readLine();
                if (request != null) {
                    double area = processRequest(request);
                    output.println(area);
                }
                clientSocket.close();
            } catch (IOException e) {
                System.err.println("Errore durante la gestione del client: " + e.getMessage());
            }
        }

        private double processRequest(String request) {
            String[] parts = request.split(" ");
            if (parts.length < 3) {
                return -1;
            }
            String figura = parts[0];
            double area = 0;

            switch (figura) {
                case "Quadrato":
                    double lato = Double.parseDouble(parts[1]);
                    area = lato * lato;
                    break;
                case "Rettangolo":
                    double base = Double.parseDouble(parts[1]);
                    double altezza = Double.parseDouble(parts[2]);
                    area = base * altezza;
                    break;
                case "Cerchio":
                    double raggio = Double.parseDouble(parts[1]);
                    area = Math.PI * raggio * raggio;
                    break;
                default:
                    break;
            }
            return area;
        }
    }
}
