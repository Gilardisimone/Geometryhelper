import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class Client {
    private static final String SERVER_ADDRESS = "localhost";
    private static final int SERVER_PORT = 80;

    public static void main(String[] args) {
        try {
            Socket socket = new Socket(SERVER_ADDRESS, SERVER_PORT);
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            String request = "Quadrato 5";
            output.println(request);

            String response = input.readLine();
            if (response != null) {
                System.out.println("Area ricevuta dal server: " + response);
            }

            socket.close();
        } catch (IOException e) {
            System.err.println("Errore durante la connessione al server: " + e.getMessage());
        }
    }
}
